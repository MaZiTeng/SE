package GROUP.RP_AF;

//external print
public class View {
    //    show the data read from the file
    public void print(String out) {
        System.out.println(out);
    }
}
