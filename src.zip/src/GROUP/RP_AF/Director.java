package GROUP.RP_AF;

public class Director extends Role {
//    include director's specific attributes
}
