package GROUP.RP_AF;

public class Admin extends Role {
//    include administrator's specific attributes for future development
}
