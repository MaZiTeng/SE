package com.company;

import java.util.Collection;
import java.util.Scanner;

public class adminFunctions {
    view p = new view();
    final Scanner myScanner = new Scanner(System.in);
    listOfRequest request;
    listOfTeacherSkills skills;
    listOfClassTeacher classes;

    public adminFunctions(listOfRequest request, listOfTeacherSkills skills, listOfClassTeacher classes) {
//        import all of the lists
        this.request = request;
        this.skills = skills;
        this.classes = classes;
    }

    public void fCheckRequest() {
        this.p.print("Check teaching requirements");
        Collection<String> dataGet = request.getRequest();
        this.p.print(String.format("%10s%10s%7s%15s", "Course Director Name", "Course Name", "Number of Teachers", "Compulsory Training"));
        //        output teaching requirements
        for (String i : dataGet) {
            String[] strArr = i.split(" ");
            System.out.printf("%10s%10s%7s%15s\n", strArr[0], strArr[1], strArr[2], strArr[3]);
        }
    }

    public void fAssignTeachers() {
        System.out.println("Assign Teachers");
        System.out.println("Please enter class name, course name, director name and teacher name. Separate them with one space");
        String data = myScanner.nextLine();
        classes.addclasses(data);
    }

    public void fUpdateSkills() {
        System.out.println("Update skills");
        System.out.println("Please enter teacher name, skill, and training status. Separate them with one space");
        String data = myScanner.nextLine();
        skills.addSkills(data);
    }

    public void fCheckSkills() {
        System.out.println("Check teaching skills");
        Collection<String> dataGet = skills.getSkills();
        System.out.printf("%10s%10s%10s\n", "Teacher Name", "Skill", "Training Status");
//        output teaching skills
        for (String i : dataGet) {
            String[] strArr = i.split(" ");
            System.out.printf("%10s%10s%10s\n", strArr[0], strArr[1], strArr[2]);
        }
    }

    public void fCheckClassTeacher() {
        System.out.println("Check Part Time Teachers");
        Collection<String> dataGet = classes.getClassess();
        System.out.printf("%10s%20s%10s%10s\n", "Class Name", "Course Name", "Director Name", "Teacher Name");
        //        output class information
        for (String i : dataGet) {
            String[] strArr = i.split(" ");
            System.out.printf("%10s%20s%10s%10s\n", strArr[0], strArr[1], strArr[2], strArr[3]);
        }
    }
}
