package com.company;

//external print
public class view {
    //    show the data read from the file
    public void print(String out) {
        System.out.println(out);
    }
}
