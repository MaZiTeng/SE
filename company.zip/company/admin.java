package com.company;

public class admin extends Role {
//    include administrator's specific attributes
}
