package com.company;

public class director extends Role {
//    include director's specific attributes
}
